﻿namespace JustAsk.Data.Models
{
    public enum VoteType
    {
        Zero = 0,
        One = 1,
        Two = 2,
        Three = 3
    }
}
