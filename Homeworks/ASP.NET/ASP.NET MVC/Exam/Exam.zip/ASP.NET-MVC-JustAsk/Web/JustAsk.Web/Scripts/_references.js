﻿/// <autosync enabled="true" />
/// <reference path="bootstrap.js" />
/// <reference path="jquery.validate.min.js" />
/// <reference path="jquery.validate.unobtrusive.js" />
/// <reference path="jquery-2.2.0.js" />
/// <reference path="jquery-2.2.0.min.js" />
/// <reference path="kendoui/kendo.all.min.js" />
/// <reference path="kendoui/kendo.aspnetmvc.min.js" />
