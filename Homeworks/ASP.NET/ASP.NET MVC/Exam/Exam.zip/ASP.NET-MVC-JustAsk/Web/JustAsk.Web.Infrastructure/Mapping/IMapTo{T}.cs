﻿namespace JustAsk.Web.Infrastructure.Mapping
{
    public interface IMapTo<T>
        where T : class
    {
    }
}
