﻿namespace JustAsk.Services.Data
{
    using JustAsk.Data.Models;

    public interface ICommentsService
    {
        void Add(Comment comment);
    }
}
