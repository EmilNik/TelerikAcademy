﻿namespace Crawler
{
    using System;
    using AngleSharp;
    using JustAsk.Data;
    using JustAsk.Data.Common;
    using JustAsk.Data.Models;

    public static class Program
    {
        public static void Main()
        {
        }
    }
}
